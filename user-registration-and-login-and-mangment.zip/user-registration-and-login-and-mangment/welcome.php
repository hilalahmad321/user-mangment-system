<?php
session_start();

if(!isset($_SESSION["name"])){
    header("location:login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="font/all.css">
    <title>welcome</title>
</head>
<body>
    <h1>Welcome <span class="w3-xxlarge w3-text-blue"> <?php echo $_SESSION["name"];?></span></h1>
    <a href="logout.php">logout</a>
</body>
</html>