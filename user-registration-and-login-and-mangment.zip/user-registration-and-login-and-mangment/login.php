<?php
session_start();

if(isset($_SESSION["name"])){
    header("location:welcome.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="font/all.css">
    <title>USER | Pannel</title>
</head>

<body>
    <div class="container">
        <?php


        if (isset($_POST["submit"])) {
            include("config.php");
            $username = $_POST["username"];
            $pass = $_POST["pass"];


            $query = "SELECT username,pass FROM registration WHERE username='{$username}' AND pass='{$pass}'";

            $result1 = mysqli_query($conn, $query);

            if (mysqli_num_rows($result1) > 0) {
                while ($row = mysqli_fetch_assoc($result1)) {
                    session_start();
                    $_SESSION["id"] = $row["id"];
                    $_SESSION["name"] = $row["username"];
                    $_SESSION["pass"] = $row["pass"];
                    header("location:welcome.php");
                }
            } else {
                echo "<p style='color:red; text-align:center;'>Invalid username and password</p>";
            }
        }
        ?>

        <form action="" method="POST">
            <label for="">Enter your username</label>
            <input type="text" name="username" class="w3-input w3-border">

            <label for="">Enter your password</label>
            <input type="password" name="pass" class="w3-input w3-border">

            <input type="submit" name="submit" value="Login" class="w3-input btn btn-info w3-border mt-3 ">

            <a href="index.php" class="mt-3 w3-center btn btn-success">Registor here</a>
        </form>
    </div>
</body>

</html>