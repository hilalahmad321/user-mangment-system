<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="font/all.css">
    <title>USER | Pannel</title>
</head>

<body>
    <div class="container mt-5" style="width: 50%;">
        <h1 class="w3-center">User Registration</h1>
        <?php

          include("config.php");

        if (isset($_POST["submit"])) {
          
            $fname = $_POST["fname"];
            $lname =  $_POST["lname"];
            $username =$_POST["username"];
            $phone = $_POST["phone"];
            $pass =$_POST["pass"];
            $cpass = $_POST["cpass"];

            $fname=mysqli_real_escape_string($conn,$fname);
            $lanme=mysqli_real_escape_string($conn,$fname);
            $username=mysqli_real_escape_string($conn,$fname);
            $phone=mysqli_real_escape_string($conn,$phone);
            $pass=mysqli_real_escape_string($conn,$pass);
            $cpass=mysqli_real_escape_string($conn,$cpass);

         $query = "SELECT username FROM registration WHERE username='{$username}'";

            $result1= mysqli_query($conn, $query);

            if (mysqli_num_rows($result1) > 0) {
                echo "<p style='color:red; text-align:center;'>username is already</p>";
            } else {
           $sql = "INSERT INTO registration(first_name,last_name,username,phone,pass,cpass)VALUES('{$fname}','{$lname}','{$username}','{$phone}','{$pass}','{$cpass}')";

                $result= mysqli_query($conn, $sql);

                if ($result) {
                    header("location:login.php");
                } else {
                    echo "<script>alert('insertion is not sucess')</script>";
                }
            }
        }
        ?>
        <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
            <label for="">Enter your first name</label>
            <input type="text" name="fname" class="w3-input w3-border">

            <label for="">Enter your last name</label>
            <input type="text" name="lname" class="w3-input w3-border">

            <label for="">Enter your username</label>
            <input type="text" name="username" class="w3-input w3-border">

            <label for="">Enter your phone name</label>
            <input type="text" name="phone" class="w3-input w3-border">

            <label for="">Enter your password </label>
            <input type="password" name="pass" class="w3-input w3-border">

            <label for="">Enter your Confirm password </label>
            <input type="password" name="cpass" class="w3-input w3-border">

            <input type="submit" name="submit" value="Registration" class="w3-input btn btn-info w3-border mt-3 ">

            <a href="login.php" class="mt-3 w3-center btn btn-success">login here</a>
        </form>
    </div>
</body>

</html>