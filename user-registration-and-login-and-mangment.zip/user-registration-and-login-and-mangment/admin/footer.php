<footer class="footer w3-black p-5 mt-5">
<span>@copyright 2020 powered by <a href="#">Hilal Ahmad</a></span>
</footer>
</bod>
</html>