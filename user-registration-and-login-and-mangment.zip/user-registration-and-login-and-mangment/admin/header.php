<?php
session_start();
if(!isset($_SESSION["name"])){
    header("location:index.php");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="font/all.css">
    <title>ADMIN | Pannel</title>
</head>
<body>
  <div class="w3-bar w3-blue p-4 w3-large">
  <a href="managuser.php" class="w3-bar-item">ADMIN DASHBORD</a>
  <a  href="logout.php"  class="w3-bar-item w3-right">logout</a>
  </div>
  <div class="w3-bar mt-2 ml-5">
      <a href="managuser.php" class="w3-bar-item w3-hover-text-white w3-hover-blue w3-white">Manage user</a>
      <form action="search.php" method="GET" class="w3-right mr-5 pr-5">
      <input type="text" name="search"> 
      <button class="w3-button" type="submit">SEARCH</button>
      </form>
  </div>