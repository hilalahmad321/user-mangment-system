<?php

$conn=mysqli_connect("localhost","root","","ums");

if(!$conn){
    echo "connection is not good";
}
?>