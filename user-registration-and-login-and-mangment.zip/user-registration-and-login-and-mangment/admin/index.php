<?php
session_start();
if(isset($_SESSION["name"])){
    header("location:managuser.php");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="font/all.css">
    <title>ADMIN | Pannel</title>
</head>
<body>
    <div class="container w3-animate-top " style="width: 30%; margin-top:10%;">
    <h1 class="w3-center w3-blue p-3">Admin Login</h1>

    <?php
   

    if(isset($_POST["submit"])){
        include("config.php");
        $name=$_POST["name"];
        $pass=$_POST["pass"];
;
        $query="SELECT * FROM admin_login WHERE username='{$name}' AND pass='{$pass}'";

        $result=mysqli_query($conn,$query);

        if(mysqli_num_rows($result)>0){
            while($row=mysqli_fetch_assoc($result)){
                session_start();
                $_SESSION["id"]=$row["id"];
                $_SESSION["name"]=$row["username"];
                header("location:managuser.php");
            }
        }else{
            ?>
            <h6 class="w3-text-red w3-center">Invalid Username and Password</h6>
            <?php
        }
    }
    ?>
        <form action="<?php $_SERVER["PHP_SELF"];?>" class=" mt-3" method="post">
            <label for="" class="w3-large  mt-3">Username</label>
            <input type="text" name="name" class="w3-input w3-border ">
            <label for="" class="w3-large  mt-3">Password</label>
            <input type="password" name="pass" class="w3-input w3-border">
            <input type="submit" value="Login" name="submit" class="w3-btn w3-blue mt-3 w3-round-xxlarge ">
            <input type="reset" class="w3-round-xxlarge w3-btn w3-right w3-blue mt-3">
        </form>
    </div>
</body>
</html>