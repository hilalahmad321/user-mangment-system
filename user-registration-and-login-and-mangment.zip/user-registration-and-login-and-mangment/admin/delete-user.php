<?php

include("config.php");

$id =$_GET["id"];
$query="DELETE FROM registration WHERE id ='$id'";


$result=mysqli_query($conn,$query);


if($result){
    header("location:managuser.php");
}

?>