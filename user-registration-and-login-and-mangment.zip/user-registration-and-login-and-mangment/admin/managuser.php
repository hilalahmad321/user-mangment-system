<?php
include("header.php");
?>
<div class="container">
    <?php
    include("config.php");

    $query = "SELECT * FROM registration";

    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {

    ?>
        <table class="w3-table-all tabl-econtant table" id="table">
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <!-- <th>Class</th> -->
                <!-- <th>Edit</th> -->
                <th>Delete</th>
            </tr>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
            ?>
                <tr>
                    <td><?php echo $row["id"] ?></td>
                    <td><?php echo $row["first_name"] . " " . $row["last_name"] ?></td>
                    <td><?php echo $row["username"] ?></td>
                    <td><?php echo $row["phone"] ?></td>
                    <!-- <td>BSCS</td> -->
                    <!-- <td><a href="#" class="fas fa-edit"></a></td> -->
                    <td><a href="delete-user.php?id=<?php echo $row['id' ] ?>" class="fas fa-trash"></a></td>
                </tr>
            <?php
            }
            ?>
        </table>
    <?php
    }
    ?>
</div>
<script src=""></script>
<?php
include("footer.php");
?>