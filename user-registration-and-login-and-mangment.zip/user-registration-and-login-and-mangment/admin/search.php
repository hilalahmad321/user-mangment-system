<?php
include("header.php");
// session_start();

if(!isset($_SESSION["name"])){
    header("location.index.php");
}
?>
<div class="container">
    <?php
    include("config.php");

    if(isset($_GET["search"])){
        $searchid=$_GET["search"];
    }
    ?>
    <h1>Search : <?php echo $searchid ;?></h1>
    <?php
    $query = "SELECT * FROM registration WHERE registration.id LIKE '%$searchid%' OR registration.first_name like '%$searchid%' OR registration.phone like '%$searchid%'";

    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {

    ?>
        <table class="w3-table-all table-contant table">
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <!-- <th>Class</th> -->
                <!-- <th>Edit</th> -->
                <th>Delete</th>
            </tr>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
            ?>
                <tr>
                    <td><?php echo $row["id"] ?></td>
                    <td><?php echo $row["first_name"] . " " . $row["last_name"] ?></td>
                    <td><?php echo $row["username"] ?></td>
                    <td><?php echo $row["phone"] ?></td>
                    <!-- <td>BSCS</td> -->
                    <!-- <td><a href="#" class="fas fa-edit"></a></td> -->
                    <td><a href="delete-user.php?id=<?php echo $row['id' ] ?>" class="fas fa-trash"></a></td>
                </tr>
            <?php
            }
            ?>
        </table>
    <?php
    }else{
        ?>
        <h1 class="w3-text-red">Not found</h1>
        <?php
    }
    ?>
</div>
<?php
include("footer.php");
?>